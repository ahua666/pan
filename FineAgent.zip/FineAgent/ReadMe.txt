﻿操作步骤如下: 
    (1) 移除之前使用的激活方式；
    (2) 在idea.vmoptions文件中引入补丁；
    (3) 重启idea；
    (4) 填入激活码；

补丁的使用方式如下: 
    -javaagent:/path/to/FineAgent.jar

